
            document.getElementById("myButton").onclick = function() {

                document.getElementById("text").innerHTML = "Hello Rob!";

            }
