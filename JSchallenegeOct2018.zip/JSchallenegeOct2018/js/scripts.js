
alert("What are my goals?");

            document.getElementById("2nd").onclick = function() {

                document.getElementById("text2").innerHTML = "Hello testing1!";

            }

                        document.getElementById("1nd").onclick = function() {

                            document.getElementById("text1").innerHTML = "Hello testing2!";

                        }

                        document.getElementById("3nd").onclick = function() {

                            document.getElementById("text3").innerHTML = "Hello testing2!";

                        }

document.getElementById("").onclick = function() {
  document.getElementById('id').style.fontsize= "50px";
}
